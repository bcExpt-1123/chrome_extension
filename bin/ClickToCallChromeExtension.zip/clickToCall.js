﻿
_clicktocall_useUs = true;
_clicktocall_customRegex = "not_set";
_clicktocall_protocol = "tel";

chrome.storage.sync.get({
    useUs: true,
    customRegex: '',
    prot: 'tel'
}, function (items) {
    _clicktocall_useUs = items.useUs;
    _clicktocall_customRegex = items.customRegex;
    _clicktocall_protocol = items.prot;

    start();
});

function start() {
    phonify(document.body);

    var mutationObserver = new MutationObserver(function (mutations) {
        mutations.forEach(function (mutation) {
            if (mutation.type === "childList")
                for (var i = mutation.addedNodes.length - 1; i >= 0; i--) {
                    var cnode = mutation.addedNodes[i];

                    if (cnode.className !== "clicktocall")
                        phonify(cnode);
                }
        });
    });

    mutationObserver.observe(document.body, { childList: true, subtree: true });
}

var handleText = function (node) {
    var regex = _clicktocall_useUs ? /(\+?(00)?1)?-? *\(?\d{3}\)?-? *\d{3}-? *-?\d{4}/ig : new RegExp(_clicktocall_customRegex, "ig");

    if (regex.test(node.nodeValue)) {

        var replacementNode = document.createElement('span');
        replacementNode.className = "clicktocall";
        replacementNode.innerHTML = node.nodeValue.replace(regex,
            "$& <a class='clicktocall' onClick='window.onbeforeunload = null; event.stopPropagation();' href='"
            + _clicktocall_protocol
            + ":$&'><img border='0' class='clicktocall' src='"
            + chrome.runtime.getURL("img/icon16.png")
            + "' ></img></a>");

        if (node.parentNode.className !== "clicktocall") {
            node.parentNode.insertBefore(replacementNode, node);
            node.parentNode.removeChild(node);
        }
    }
};

var walk = function (node) {
    if (node.nodeType === 3) {
        handleText(node);
        return;
    }

    Array.prototype.forEach.call(
        node.childNodes,
        (childNode) => {
            const { tagName } = childNode;
            if (tagName !== 'SCRIPT' && tagName !== 'NOSCRIPT' && tagName !== 'STYLE') {
                walk(childNode);
            }
        }
    );
};

var phonify = function (node) {

    if (node.nodeType !== 1)
        return;

    walk(node);
};
